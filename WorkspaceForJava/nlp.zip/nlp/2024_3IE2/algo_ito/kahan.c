#include<stdio.h>
#include<math.h>

int main(void){
    unsigned char c = 0.0;
    int i;
    printf("%f\n",M_PI);
}
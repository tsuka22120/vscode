#include<bits/stdc++.h>

int main(){
    int a,b,c;
    std::string s;
    std::cin >> a;
    std::cin >> b >> c;
    std::cin >> s;
    std::cout << a + b + c << std::endl;
    std::cout << s << std::endl;
    return 0;
}
public class 爬虫類 extends 脊椎動物 {

	private int 肌のうるおい;

	public void 硬くなる() {

	}

}

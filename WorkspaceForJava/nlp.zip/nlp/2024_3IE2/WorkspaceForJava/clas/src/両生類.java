public class 両生類 extends 脊椎動物 {

	private int 体温;

	public void 歩く() {

	}

}

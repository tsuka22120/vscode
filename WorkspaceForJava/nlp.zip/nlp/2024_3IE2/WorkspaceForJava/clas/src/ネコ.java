public class ネコ extends 哺乳類 {

	private int かわいさ;

	public void 食事() {

	}

}

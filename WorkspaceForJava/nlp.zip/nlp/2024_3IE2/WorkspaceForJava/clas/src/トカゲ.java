public class トカゲ extends 爬虫類 {

	private int 生存力;

	public void 脱皮() {

	}

}

public class サバ extends 魚類 {

	private int 重量;

	public void 鰓呼吸() {

	}

}

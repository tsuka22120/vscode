public class 無脊椎動物 extends いきもの {

	public void 動く() {

	}

}

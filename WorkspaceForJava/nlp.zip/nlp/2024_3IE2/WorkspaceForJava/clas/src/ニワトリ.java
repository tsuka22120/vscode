public class ニワトリ extends 鳥類 {

	private int 年齢;

	public void 産む() {

	}

}

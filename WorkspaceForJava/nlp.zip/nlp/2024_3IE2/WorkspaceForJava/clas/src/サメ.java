public class サメ extends 魚類 {

	private int 重量;

	public void 捕食() {

	}

}

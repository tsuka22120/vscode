public class カエル extends 両生類 {

	private int ジャンプ力;

	public void 鳴く() {

	}

}

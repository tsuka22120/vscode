public class コアラ extends 哺乳類 {

	private int 年齢;

	public void 寝る() {

	}

}

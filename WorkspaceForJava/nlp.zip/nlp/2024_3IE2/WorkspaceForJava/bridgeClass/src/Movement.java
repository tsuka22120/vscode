abstract public class Movement {
    abstract public void forward();

    abstract public void back();

    abstract public void turn(Boolean side);

    abstract public void call();
}
interface Strategy {
    public abstract Integer nextNumber(int i);

    public abstract void learning(int enemyNumber);
}
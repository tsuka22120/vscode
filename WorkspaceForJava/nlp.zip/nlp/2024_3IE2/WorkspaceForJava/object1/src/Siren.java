public interface Siren {
  public void  callSiren() ;
}
public class Main {
        static public void main(String args[]) {
                goingOut school = new school();
                school.working();
                goingOut friendsHouse = new friendsHouse();
                friendsHouse.working();
        }
}
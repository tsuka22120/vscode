// // forとかの構造が色で分かりやすい

// while (1) {
//     if (1) {
//         printf("うんち\n");  // コードを整えてくれる
//     }

//     // Ctrl + Sで整う
//     free();

//     free();
// //gccで実行しようとしたらどっちも同じじゃね？
// //こっちもボタンぽちできるよ
//     printf("とてもぐっど\n");  // コードを整えてくれる
// }
#include <stdio.h>

int main(void){
    printf("Hello, World!\n");
    printf("VScodeでC言語プログラムを書いてみよう！\n");
    printf("やっぱり便利なのはファイルの構造がわかりやすい所だよね\n");
    
    return 0;
}//ほら、ぽちでもできる
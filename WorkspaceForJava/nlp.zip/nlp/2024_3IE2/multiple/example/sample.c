#include <stdio.h>
#include "mulprec.h"


int main(int argc, char** argv) {
    struct NUMBER a;
    clearByZero(&a);
    printf("success\n");
    return 0;
}